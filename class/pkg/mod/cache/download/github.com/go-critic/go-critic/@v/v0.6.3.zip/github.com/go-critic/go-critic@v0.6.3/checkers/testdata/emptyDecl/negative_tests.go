package checkers

func _() {
	var (
		x int
	)
	const (
		y = 2
	)
	type (
		z string
	)
	_ = x
}

var (
	gx = 0
)

const (
	gy = 2
)

type (
	gz string
)
