package checker_test

func _(x, y string) {
	_ = x + "_" + y

	_ = x + y
}
