package checker_test

func ExampleFoo() {
	// TODO: something important
	// TODO(jim)
	// FIX fix this
	// FIXME(bob)
	//     TODO this
	// BUG: oh no this is broken
}
