package files

import "net/http"

// ignored file

func example2() {
	http.StatusText(200)
}
