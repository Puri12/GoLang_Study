package crypto

func MD4() {
	_ = "MD4" // want `"MD4" can be replaced by crypto.MD4.String\(\)`
}
