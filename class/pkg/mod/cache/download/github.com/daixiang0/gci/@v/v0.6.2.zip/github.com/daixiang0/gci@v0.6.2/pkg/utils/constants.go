package utils

const (
	Indent    = '\t'
	Linebreak = '\n'

	SectionSeparator = ":"

	ParameterOpeningBrackets = "("
	ParameterClosingBrackets = ")"
)
