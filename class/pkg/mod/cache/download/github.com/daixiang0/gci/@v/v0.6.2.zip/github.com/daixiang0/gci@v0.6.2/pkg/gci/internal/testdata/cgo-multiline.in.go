package main

import (
	// #include "types.h"
	// #include "other.h"
	"C"
)
