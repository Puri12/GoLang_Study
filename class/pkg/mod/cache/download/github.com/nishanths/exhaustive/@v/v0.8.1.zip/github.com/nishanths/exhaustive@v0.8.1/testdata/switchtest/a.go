package switchtest

type Biome int

const (
	Tundra  Biome = 1
	Savanna Biome = 2
	Desert  Biome = 3
)
