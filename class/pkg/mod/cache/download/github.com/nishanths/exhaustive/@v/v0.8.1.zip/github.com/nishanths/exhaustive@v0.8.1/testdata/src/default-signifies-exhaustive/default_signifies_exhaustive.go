package dse

type T int

const (
	A T = iota
	B
)
