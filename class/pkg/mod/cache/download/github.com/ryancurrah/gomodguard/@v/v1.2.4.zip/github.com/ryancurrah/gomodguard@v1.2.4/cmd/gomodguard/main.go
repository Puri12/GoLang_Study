package main

import (
	"os"

	"github.com/ryancurrah/gomodguard"
)

func main() {
	os.Exit(gomodguard.Run())
}
