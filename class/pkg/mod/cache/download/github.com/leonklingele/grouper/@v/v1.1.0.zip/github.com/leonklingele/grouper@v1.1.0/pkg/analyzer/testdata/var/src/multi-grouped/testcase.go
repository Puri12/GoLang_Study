package testcase

var (
	a = "a"
	b = "b"

	_ = "underscore1"
)

func dummy() {
	var (
		_ = "ignore1"
		_ = "ignore2"
	)
}
