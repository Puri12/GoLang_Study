package bad // want "package should be `bad_test` instead of `bad`"
