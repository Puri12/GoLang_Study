//nolint: varcheck
package testdata

var nolintVarcheck int
