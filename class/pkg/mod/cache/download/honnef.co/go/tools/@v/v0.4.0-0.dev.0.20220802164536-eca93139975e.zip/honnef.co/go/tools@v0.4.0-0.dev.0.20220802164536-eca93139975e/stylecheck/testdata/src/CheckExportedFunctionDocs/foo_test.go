package pkg

import "testing"

// This is a test
func TestFoo(t *testing.T) {}
