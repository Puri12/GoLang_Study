package pkg

func (t1) fn4() {} //@ used(true)
